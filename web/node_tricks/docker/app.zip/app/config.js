module.exports = {
	flag : "flag{xxx}",
	secret : "xxx"
}